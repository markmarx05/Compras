export type Item = {
    id: number;
    name: string;
    done: boolean;
}